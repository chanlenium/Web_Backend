const express = require("express");
const app = express();

let appName = "Week 4 demo app"

// the 3rd middleware for parsing data in the http body
const bodyParser = require('body-parser');

app.use(bodyParser.json());

// setup the static folder that static resources can load from
// like images, css files, etc.
app.use(express.static("static"));


// app.use(handleClientError);

// for Error handling
function handleClientError(err, req, res, next) {
    // log the error to the DB with a utility method to log errors  
    logError(err);
  
    // if the request was an xhr request respond with a 500 status and JSON message
    // otherwise respond with a string message
    if (req.xhr) {
      res.status(500).send({ message: 'There was an error processing your request' })
    } else {
      res.status(500).send('Something went wrong processing your request')
    }  
}
  


// the default ('root') route
app.get("/", (req, res) => {
  res.send("hello world<br>" + 
           "The image in the static folder: <a href='/Express.js.png'>Express.js.png</a>" +
           "<br><img src='/Express.js.png' alt='Express.js' /><br><br>" +
           "<button onclick=\'window.open(\"/headers\", \"_blank\",\"\");\'>Show Headers (page)<button>");
});

// now add a route for the /headers page
// IE: http://localhost:8080/headers
app.get("/headers", /*handleClientError, */(req, res) => {
    const headers = req.headers;

    console.log("headers: ", headers); // for debugging

    res.send(headers);
});

app.get("/request", (req, res) => {
    const reqInfo = req.get("User-Agent");
    res.send(reqInfo);
});

app.use((req, res) => {
    res.status(404).send("<h4>Error! <br> 404 <br> Page not found.</h4>");
});


app.listen(8080, ()=>{
    console.log("Server start to listen to port 8080");
});


// * 3 important objects in express.js:
//   app, req, res

// * Routing - Defining routes in Express.js. The structure is:
//   app.METHOD(PATH, HANDLER)


// * app.get() vs app.post() in WEB APPs 
//   1. app.post() - is used for processing FORM submission: the form data is in the http body, <form method="post">...
//   2. app.get() - is used for presenting html FORM, web page, text in a web page
//   -. note: we don't use app.update() or app.delete() in web apps


// * What are the CRUD operations for manupilating data, Web API (e.g. week 9), +...
//   C - Create new entity - corresponding HTTP method: post, so app.post() is used (in Web API)
//   R - Retrivev/Read:
//       Get All (entities) - corresponding HTTP method: get, so app.get() is used (in Web API)
//       Get One            - corresponding HTTP method: get, so app.get()  is used (in Web API)
//   U - Update/Edit existing (entity) - corresponding HTTP method: update, so app.update() is used (in Web API)
//                                                                  patch (partially update, seldom-used)
//   D - Delete item (/entity) - corresponding HTTP method, delete, so app.delete() in Web API


// * The 3 ways to use http request to send data to server
//   1. using query string on url, e.g. ?fname=John&lname=Doe - to access the data on server: req.query.fname
//   2. using the body of http request  e.g. fname=John and lname=Doe - to access the data on server: req.body.fname
//   3. using parameter in the route, e.g. route: /user/:id - to access the data on server: req.params.id

// * easy-to-use debugging tool
//   console.log("variable name or desc: ", dataVar);