
/**** Node.js - Hello World! */
console.log("Hello World!");

/**** Node.js: Global objects and variables and functions */
console.log("__dirname", __dirname);
console.log("__filename in hello.js: ", __filename);

console.time('100-elements');
for (let i = 0; i < 100; i++) {}
console.timeEnd('100-elements');

// Global function: setTimeout()
console.log("starting...");
setTimeout(function(){
    console.log("Hello after 2 second");
}, 2000);

// Global function: setInterval()
var count = 1; // global counter
var maxCount = 5; // global maximum

var myCountInterval = setInterval(function () {
    console.log("Hello after " + (count++) + " second(s)");
    checkMaximum();
}, 1000);

var checkMaximum = function () {
    if (count > maxCount) {
        clearInterval(myCountInterval);
    }
}

// Global function: require()
var readline = require('readline');

var rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('Enter Your Name: ', function(answer){
  console.log('Hello ' +  answer);
  rl.close();
});

