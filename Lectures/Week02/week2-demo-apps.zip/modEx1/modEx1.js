var message = require("./modules/message.js");

message.writeMessage("Hello World!");

message.readMessage();
